---
name: Feature
about: Nova funcionalidade com critérios de aceitação verificáveis
labels: []
---

## Contexto
<!-- Por que esta mudança é necessária. -->

## Critérios de aceitação
<!-- Um por linha, verificáveis. Os testes citam o número: [C1], [C2]... -->
- [ ] C1:
- [ ] C2:
- [ ] C3: (caso negativo: entrada inválida, limite + 1, usuário sem permissão)

## Fora do escopo
-

## Área crítica?
- [ ] Autenticação  - [ ] Pagamentos  - [ ] Dados pessoais  - [ ] Nenhuma
