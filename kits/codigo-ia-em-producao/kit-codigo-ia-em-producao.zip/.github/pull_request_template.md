## O que este PR faz
<!-- Uma ou duas frases. -->
Closes #

## Dependências novas
<!-- Pacote, versão e por que é necessário. "Nenhuma" se não houver. -->

## Plano de rollback
<!-- "Reverter o PR" ou os passos, se houver migração ou dados. -->

## Autor
- [ ] O PR resolve uma issue só e é pequeno o bastante para ser lido de uma vez
- [ ] Rótulo `ia:*` aplicado; ferramenta usada, se houve IA: ___
- [ ] Li cada linha do diff e consigo explicar o que ela faz
- [ ] Cada critério de aceitação tem um teste com o número do critério no nome, incluindo casos negativos
- [ ] Não alterei, pulei nem isolei testes existentes sem explicar acima
- [ ] Nenhum segredo, dado pessoal real ou URL interna no código, nos testes ou nos prompts
- [ ] Instruções de agentes não foram alteradas, ou estão num PR separado

## Revisor de IA
- [ ] A revisão de IA rodou sobre a versão final do diff
- [ ] Cada comentário foi respondido (corrigido / falso positivo com motivo / fora do escopo com issue)

<!-- Revisor humano: use a lista de docs/revisao.md -->
