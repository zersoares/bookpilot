# Instruções do repositório para o GitHub Copilot


Projeto: Next.js (App Router) + TypeScript.

Sempre sinalize:
- Conteúdo vindo do usuário renderizado sem escape, incluindo
  `dangerouslySetInnerHTML` e montagem de HTML por string.
- Consultas ao banco montadas por concatenação ou template string,
  em vez de consultas parametrizadas ou do ORM.
- Route handlers e server actions sem validação de entrada no servidor.
- Rotas em `app/api/` ou server actions sem checagem de autenticação
  e autorização.
- Segredos, tokens ou URLs internas no código ou em variáveis
  `NEXT_PUBLIC_*`.
- Saída de modelo de IA usada em HTML, SQL, shell ou `eval`
  sem tratamento.
- Hash de senha que não seja um algoritmo próprio para senhas.

## Testes
- Sinalize testes alterados para passar, `.skip`/`.only`, snapshots
  novos sem justificativa e mocks do Prisma em testes de rotas.
- Sinalize critérios de aceitação da issue sem teste correspondente.

## Segurança (OWASP Top 10:2025 e LLM Top 10 2025)
- Server Actions e route handlers: verificar autenticação E autorização
  dentro de cada um; filtros do Prisma devem incluir o dono do registro.
- Sinalizar `$queryRawUnsafe`, `$executeRawUnsafe` e SQL montado por string.
- Sinalizar `dangerouslySetInnerHTML`, HTML por string e URLs do usuário
  em `href`/`src`.
- Sinalizar novas variáveis `NEXT_PUBLIC_*` e qualquer segredo no código.
- Sinalizar dependências novas e dizer o que cada uma faz.
- Saída de modelo de IA: nunca em HTML, SQL, shell, `eval` ou caminho de
  arquivo sem validação.

Não comente sobre formatação: o ESLint e o Prettier cuidam disso.
