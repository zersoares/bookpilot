---
name: Feature
about: New feature with verifiable acceptance criteria
labels: []
---

## Context
<!-- Why this change is needed. -->

## Acceptance criteria
<!-- One per line, verifiable. Tests cite the number: [C1], [C2]... -->
- [ ] C1:
- [ ] C2:
- [ ] C3: (negative case: invalid input, limit + 1, user without permission)

## Out of scope
-

## Critical area?
- [ ] Authentication  - [ ] Payments  - [ ] Personal data  - [ ] None
