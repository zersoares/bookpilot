# Checklist de PR com código de IA (versão curta)
- [ ] 1. O PR resolve uma issue com critérios de aceitação, e é pequeno o bastante para ser lido de uma vez
- [ ] 2. Está indicado se houve IA e qual ferramenta
- [ ] 3. O autor leu cada linha do diff e consegue explicá-la
- [ ] 4. Cada critério de aceitação tem um teste que falharia se o código estivesse errado
- [ ] 5. Há testes de entrada inválida e de usuário sem permissão
- [ ] 6. Autenticação e autorização são verificadas no servidor, em cada rota e Server Action
- [ ] 7. Nenhuma consulta montada com entrada externa e nenhum HTML sem escape (incluindo saída de modelo de IA)
- [ ] 8. Nenhum segredo no código, nos prompts ou em variáveis públicas; dependências novas verificadas
- [ ] 9. Cada comentário do revisor de IA foi respondido, e um humano aprovou (aprovação de IA não conta)
- [ ] 10. CI verde e plano de rollback definido

Do e-book *Código de IA em Produção*, de Zirlandia Milkovic.
