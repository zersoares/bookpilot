# Revisão de PR — revisor humano e merge

Use junto com o template de PR. Áreas críticas: auth, pagamentos, dados pessoais.

### Áreas críticas
- [ ] Nas áreas críticas, foi pedida uma revisão mais profunda (Deep no Claude / Balanced no Copilot)

### Revisor humano
**Especificação e testes**
- [ ] Li a issue antes do código; o PR faz o que ela pede, e nada além
- [ ] Cada critério de aceitação tem teste, e o teste falharia se a implementação estivesse errada
- [ ] Testes existentes alterados, `skip`, `only`, snapshots e mocks novos foram justificados
- [ ] Rotas e Server Actions têm teste de integração com banco real, e não só com mock do Prisma

**Segurança (capítulo 5)**
- [ ] Toda Server Action e todo route handler verificam autenticação e autorização por conta própria
- [ ] Consultas do Prisma a dados de usuário filtram pelo dono do registro
- [ ] Nenhum `$queryRawUnsafe`/`$executeRawUnsafe` nem SQL montado com entrada externa
- [ ] Nenhum `dangerouslySetInnerHTML`, HTML por string ou URL do usuário em `href`/`src` sem tratamento
- [ ] Nenhuma variável `NEXT_PUBLIC_*` nova com valor que não possa ser público
- [ ] Saída de modelo de IA é validada, exibida como texto e não dispara ações sozinha
- [ ] Dependências novas: existem, são mantidas, são necessárias, licença compatível

**Qualidade**
- [ ] Erros e logs não expõem dados pessoais, segredos ou detalhes internos
- [ ] Sem código morto, duplicado ou chamadas a APIs e funções que não existem
- [ ] Os comentários do revisor de IA marcados como "falso positivo" são mesmo falsos positivos

### Merge
- [ ] CI verde: lint, `tsc`, testes, e2e das rotas afetadas, CodeQL, revisão de dependências, rótulo `ia:*`
- [ ] Cobertura das linhas alteradas verificada; a cobertura do projeto não caiu
- [ ] Aprovação humana registrada (1 aprovação; 2 do time crítico em auth, pagamentos e dados pessoais)
- [ ] Nenhuma aprovação do Copilot foi contada para o merge (decisão do time, capítulo 3)
- [ ] Sei como reverter: o PR pode ser revertido sozinho, ou o plano de rollback está descrito abaixo
- [ ] Migrações do Prisma (se houver) foram revisadas e são compatíveis com a versão anterior do app durante o deploy
