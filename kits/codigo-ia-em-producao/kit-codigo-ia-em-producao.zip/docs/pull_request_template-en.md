## What this PR does
<!-- One or two sentences. -->
Closes #

## New dependencies
<!-- Package, version and why it is needed. "None" if there are none. -->

## Rollback plan
<!-- "Revert the PR" or the steps, if there is a migration or data change. -->

## Author
- [ ] The PR solves a single issue and is small enough to read in one sitting
- [ ] `ia:*` label applied; tool used, if AI was involved: ___
- [ ] I read every line of the diff and can explain what it does
- [ ] Each acceptance criterion has a test with the criterion number in its name, including negative cases
- [ ] I did not change, skip or isolate existing tests without explaining above
- [ ] No secrets, real personal data or internal URLs in code, tests or prompts
- [ ] Agent instructions were not changed, or are in a separate PR

## AI reviewer
- [ ] The AI review ran on the final version of the diff
- [ ] Every comment was answered (fixed / false positive with reason / out of scope with issue)

<!-- Human reviewer: use the list in docs/revisao.md -->
