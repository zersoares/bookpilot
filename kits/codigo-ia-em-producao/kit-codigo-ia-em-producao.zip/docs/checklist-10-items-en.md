# PR checklist for AI-generated code (short version)
- [ ] 1. The PR resolves one issue with acceptance criteria, and is small enough to read in one sitting
- [ ] 2. It states whether AI was used, and which tool
- [ ] 3. The author has read every line of the diff and can explain it
- [ ] 4. Every acceptance criterion has a test that would fail if the code were wrong
- [ ] 5. There are tests for invalid input and for users without permission
- [ ] 6. Authentication and authorization are checked on the server, in every route and Server Action
- [ ] 7. No query built from external input and no unescaped HTML (including AI model output)
- [ ] 8. No secrets in code, prompts or public variables; new dependencies verified
- [ ] 9. Every AI reviewer comment has been answered, and a human approved (AI approval doesn't count)
- [ ] 10. CI is green and a rollback plan is defined

From the e-book *Código de IA em Produção* by Zirlandia Milkovic.
