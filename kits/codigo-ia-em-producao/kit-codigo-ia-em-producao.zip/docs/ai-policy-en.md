# AI use policy for development — [Team name]
Version: 1.0 · Reviewed on: [date] · Next review: [date + 6 months]
Owner: [name] · Data protection officer (encarregado): [name/contact]

## 1. Allowed tools
- Development: Claude Code and GitHub Copilot, on organization accounts.
- Product features: Claude API (Anthropic); alternative: Grok (xAI) only with ZDR.
- Any other tool needs approval from [owner].

## 2. Review and approval
- Every PR gets the AI review and at least 1 human approval.
- Auth, payments and personal data: 2 approvals from @[team]/criticos.
- AI approval does not count toward merge (Copilot approvals: off).
- Agent instructions, CI and templates are critical code.

## 3. Accountability
- Whoever opens the PR (or asks the agent to) is accountable for it.
- Every PR has one label: ia:agente, ia:assistido or ia:nenhum.
  ia:assistido = more than half of the diff came from AI.

## 4. Data
- Never: production personal data, secrets or credentials in prompts,
  issues, agent sessions or logs.
- Tests and examples use fictitious data only.
- Client code: only with the tools authorized in the contract.

## 5. Quality
- Checklists: lean template + docs/revisao.md.
- Required CI: lint, types, tests, affected e2e, CodeQL,
  dependencies, secret scanning, ia:* label.
- Metrics reviewed monthly (docs/painel-metricas-en.xlsx).

## 6. Incidents
- Reverts/hotfixes record the originating PR.
- Suspected personal-data incident: notify [DPO] within [deadline].

## 7. Review of this policy
- Every 6 months, or when a tool or its terms of use change.
