# Repository instructions for GitHub Copilot

Project: Next.js (App Router) + TypeScript.

Always flag:
- User-supplied content rendered without escaping, including
  `dangerouslySetInnerHTML` and HTML built from strings.
- Database queries built by concatenation or template strings
  instead of parameterized queries or the ORM.
- Route handlers and server actions without server-side input validation.
- Routes in `app/api/` or server actions without authentication
  and authorization checks.
- Secrets, tokens or internal URLs in code or in `NEXT_PUBLIC_*`
  variables.
- AI model output used in HTML, SQL, shell or `eval`
  without handling.
- Password hashing that is not a dedicated password algorithm.

## Tests
- Flag tests changed to pass, `.skip`/`.only`, new snapshots
  without justification and Prisma mocks in route tests.
- Flag issue acceptance criteria without a matching test.

## Security (OWASP Top 10:2025 and LLM Top 10 2025)
- Server Actions and route handlers: check authentication AND authorization
  inside each one; Prisma filters must include the record owner.
- Flag `$queryRawUnsafe`, `$executeRawUnsafe` and SQL built from strings.
- Flag `dangerouslySetInnerHTML`, HTML built from strings and user URLs
  in `href`/`src`.
- Flag new `NEXT_PUBLIC_*` variables and any secret in code.
- Flag new dependencies and say what each one does.
- AI model output: never in HTML, SQL, shell, `eval` or a file
  path without validation.

Do not comment on formatting: ESLint and Prettier handle it.
