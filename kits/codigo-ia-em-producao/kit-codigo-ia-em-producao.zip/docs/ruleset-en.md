# Ruleset configuration (default branch) — reference

Settings → Rules → Rulesets, on the default branch. Example-project values (chapter 3).

## Branch rules
- Restrict deletions and Block force pushes.
- Require a pull request before merging:
  - Required approvals: **1**
  - Dismiss stale pull request approvals when new commits are pushed
  - Require review from Code Owners
  - Require approval of the most recent reviewable push
  - Require conversation resolution before merging
- Require an additional approval for unattributed Copilot pull requests: **on** (preview).
- Require status checks to pass: lint, `tsc`, tests, e2e, CodeQL,
  dependency review and `rotulo-ia`; Require branches to be up to date.
- Require secret scanning alerts are resolved (preview, chapter 5).
- Bypass list: **empty**.

## Required reviewers (organizations only)
Team `@exemplo/criticos`, **2 approvals**, patterns:

```gitignore
app/(auth)/**
app/api/auth/**
lib/auth/**
proxy.ts
app/api/pagamentos/**
lib/pagamentos/**
lib/dados-pessoais/**
prisma/schema.prisma
```

## Copilot (organization settings)
Copilot approvals counting toward merge: **Disabled everywhere**.

## Solo dev (personal account, chapter 3, section 3.5)
Required approvals: 0 · conversations resolved · all status checks ·
Block force pushes and Restrict deletions · empty bypass · AI review on every push.

## Labels
`ia:agente` · `ia:assistido` (more than half of the diff came from AI) · `ia:nenhum`
