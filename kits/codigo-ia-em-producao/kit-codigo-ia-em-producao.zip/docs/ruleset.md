# Configuração do ruleset (branch padrão) — referência

Settings → Rules → Rulesets, na branch padrão. Valores do projeto-exemplo (capítulo 3).

## Branch rules
- Restrict deletions e Block force pushes.
- Require a pull request before merging:
  - Required approvals: **1**
  - Dismiss stale pull request approvals when new commits are pushed
  - Require review from Code Owners
  - Require approval of the most recent reviewable push
  - Require conversation resolution before merging
- Require an additional approval for unattributed Copilot pull requests: **ligada** (prévia).
- Require status checks to pass: lint, `tsc`, testes, e2e, CodeQL,
  verificação de dependências e `rotulo-ia`; Require branches to be up to date.
- Require secret scanning alerts are resolved (prévia, capítulo 5).
- Bypass list: **vazia**.

## Required reviewers (só em organização)
Time `@exemplo/criticos`, **2 aprovações**, padrões:

```gitignore
app/(auth)/**
app/api/auth/**
lib/auth/**
proxy.ts
app/api/pagamentos/**
lib/pagamentos/**
lib/dados-pessoais/**
prisma/schema.prisma
```

## Copilot (configuração da organização)
Contagem de aprovações do Copilot para o merge: **Disabled everywhere**.

## Dev solo (conta pessoal, capítulo 3, seção 3.5)
Required approvals: 0 · conversas resolvidas · todos os status checks ·
Block force pushes e Restrict deletions · bypass vazio · revisão de IA a cada push.

## Rótulos
`ia:agente` · `ia:assistido` (mais da metade do diff veio de IA) · `ia:nenhum`
