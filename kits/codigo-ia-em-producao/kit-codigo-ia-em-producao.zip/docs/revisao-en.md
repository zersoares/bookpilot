# PR review — human reviewer and merge

Use together with the PR template. Critical areas: auth, payments, personal data.

### Critical areas
- [ ] In critical areas, a deeper review was requested (Deep in Claude / Balanced in Copilot)

### Human reviewer
**Specification and tests**
- [ ] I read the issue before the code; the PR does what it asks, and nothing more
- [ ] Each acceptance criterion has a test, and the test would fail if the implementation were wrong
- [ ] Changed existing tests, `skip`, `only`, new snapshots and mocks are justified
- [ ] Routes and Server Actions have integration tests against a real database, not only a Prisma mock

**Security (chapter 5)**
- [ ] Every Server Action and route handler checks authentication and authorization on its own
- [ ] Prisma queries on user data filter by the record owner
- [ ] No `$queryRawUnsafe`/`$executeRawUnsafe` and no SQL built from external input
- [ ] No `dangerouslySetInnerHTML`, HTML built from strings or user URLs in `href`/`src` without handling
- [ ] No new `NEXT_PUBLIC_*` variable with a value that cannot be public
- [ ] AI model output is validated, displayed as text and does not trigger actions on its own
- [ ] New dependencies: they exist, are maintained, are necessary, and have a compatible license

**Quality**
- [ ] Errors and logs do not expose personal data, secrets or internal details
- [ ] No dead or duplicated code, and no calls to APIs or functions that do not exist
- [ ] AI reviewer comments marked as "false positive" really are false positives

### Merge
- [ ] CI green: lint, `tsc`, tests, e2e for affected routes, CodeQL, dependency review, `ia:*` label
- [ ] Coverage of changed lines checked; project coverage did not drop
- [ ] Human approval recorded (1 approval; 2 from the critical team for auth, payments and personal data)
- [ ] No Copilot approval was counted toward the merge (team decision, chapter 3)
- [ ] I know how to roll back: the PR can be reverted on its own, or the rollback plan is described above
- [ ] Prisma migrations (if any) were reviewed and are compatible with the previous app version during deploy
