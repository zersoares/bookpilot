# Política de uso de IA no desenvolvimento — [Nome do time]
Versão: 1.0 · Revisada em: [data] · Próxima revisão: [data + 6 meses]
Responsável: [nome] · Encarregado(a) de dados: [nome/contato]

## 1. Ferramentas permitidas
- Desenvolvimento: Claude Code e GitHub Copilot, em contas da organização.
- Features do produto: API do Claude (Anthropic); alternativa: Grok (xAI) só com ZDR.
- Qualquer outra ferramenta precisa de aprovação de [responsável].

## 2. Revisão e aprovação
- Todo PR passa pela revisão de IA e por pelo menos 1 aprovação humana.
- Auth, pagamentos e dados pessoais: 2 aprovações de @[time]/criticos.
- Aprovação de IA não conta para o merge (Copilot approvals: desligado).
- Instruções de agentes, CI e templates são código crítico.

## 3. Responsabilidade
- Quem abre o PR (ou pede ao agente) responde por ele.
- Todo PR tem um rótulo: ia:agente, ia:assistido ou ia:nenhum.
  ia:assistido = mais da metade do diff veio de IA.

## 4. Dados
- Nunca: dados pessoais de produção, segredos ou credenciais em prompts,
  issues, sessões de agentes ou logs.
- Testes e exemplos usam só dados fictícios.
- Código de cliente: só com as ferramentas autorizadas no contrato.

## 5. Qualidade
- Checklists: template enxuto + docs/revisao.md.
- CI obrigatório: lint, tipos, testes, e2e afetados, CodeQL,
  dependências, secret scanning, rótulo ia:*.
- Métricas revisadas mensalmente (docs/painel-metricas.xlsx).

## 6. Incidentes
- Revert/hotfix registram o PR de origem.
- Suspeita de incidente com dados pessoais: avisar [encarregado] em até [prazo].

## 7. Revisão desta política
- A cada 6 meses, ou quando uma ferramenta ou termo de uso mudar.
