# Full review lists (alternative)

For teams that prefer all four lists in one place, in the PR template.

### Author
- [ ] The PR solves a single issue, with link: Closes #___
- [ ] The PR is small enough to read in one sitting (if not, I split it)
- [ ] Code origin: label `ia:agente`, `ia:assistido` or `ia:nenhum` applied
- [ ] Tool used, if AI was involved: ___ (Claude Code / Copilot / other)
- [ ] I read every line of the diff and can explain what it does
- [ ] Each acceptance criterion has a test, with the criterion number in its name
- [ ] There are negative tests: invalid input, limit + 1, user without permission
- [ ] I did not change, skip (`skip`) or isolate (`only`) existing tests without explaining below
- [ ] No secrets, real personal data or internal URLs in code, tests or prompts
- [ ] New dependencies (if any) are listed below, with the reason
- [ ] Agent instruction files (`AGENTS.md`, `REVIEW.md`, `CLAUDE.md`, `.github/copilot-instructions.md`, `.github/instructions/`) were not changed, or are in a separate PR

### AI reviewer
- [ ] The AI review ran on the final version of the diff (new review after the last relevant push)
- [ ] Every comment was answered: fixed / false positive (with reason) / out of scope (with an open issue)
- [ ] All conversations were resolved
- [ ] In critical areas, a deeper review was requested (Deep in Claude / Balanced in Copilot)

### Human reviewer
**Specification and tests**
- [ ] I read the issue before the code; the PR does what it asks, and nothing more
- [ ] Each acceptance criterion has a test, and the test would fail if the implementation were wrong
- [ ] Changed existing tests, `skip`, `only`, new snapshots and mocks are justified
- [ ] Routes and Server Actions have integration tests against a real database, not only a Prisma mock

**Security (chapter 5)**
- [ ] Every Server Action and route handler checks authentication and authorization on its own
- [ ] Prisma queries on user data filter by the record owner
- [ ] No `$queryRawUnsafe`/`$executeRawUnsafe` and no SQL built from external input
- [ ] No `dangerouslySetInnerHTML`, HTML built from strings or user URLs in `href`/`src` without handling
- [ ] No new `NEXT_PUBLIC_*` variable with a value that cannot be public
- [ ] AI model output is validated, displayed as text and does not trigger actions on its own
- [ ] New dependencies: they exist, are maintained, are necessary, and have a compatible license

**Quality**
- [ ] Errors and logs do not expose personal data, secrets or internal details
- [ ] No dead or duplicated code, and no calls to APIs or functions that do not exist
- [ ] AI reviewer comments marked as "false positive" really are false positives

### Merge
- [ ] CI green: lint, `tsc`, tests, e2e for affected routes, CodeQL, dependency review, `ia:*` label
- [ ] Coverage of changed lines checked; project coverage did not drop
- [ ] Human approval recorded (1 approval; 2 from the critical team for auth, payments and personal data)
- [ ] No Copilot approval was counted toward the merge (team decision, chapter 3)
- [ ] I know how to roll back: the PR can be reverted on its own, or the rollback plan is described above
- [ ] Prisma migrations (if any) were reviewed and are compatible with the previous app version during deploy
