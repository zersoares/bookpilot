# AGENTS.md — rules for coding agents

Project: Next.js (App Router) + TypeScript + Prisma. Input validation in
plain TypeScript (no schema library), in functions under `lib/validacao/`.

## Scope
- Solve only the referenced issue. Do not change code outside its scope.
- Do not change `AGENTS.md`, `REVIEW.md`, `CLAUDE.md` or anything in `.github/`.

## Tests
- Write tests from the issue's acceptance criteria.
- Each test name starts with the criterion number: "[C3] ...".
- Do not change existing tests to make them pass. If you think a
  test is wrong, explain it in the PR description.
- Do not use `.skip`, `.only` or `test.todo` in code meant for merge.
- For invalid-input cases, check the error response and
  that nothing was written to the database.

## Data and secrets
- Never use real personal data in code, tests, seeds or examples.
- Never put secrets in code or in `NEXT_PUBLIC_*` variables.
- Logs do not record personal data (log IDs, not content).

## Security
- Every Server Action and route handler checks authentication and
  authorization inside itself (helper `obterSessao`).
- Queries on user data filter by the record owner.
- AI model output is validated and displayed as text.
- List every new dependency and the reason in the PR description.
