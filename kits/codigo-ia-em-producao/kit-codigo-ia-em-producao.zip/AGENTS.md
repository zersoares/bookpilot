# AGENTS.md — regras para agentes de código

Projeto: Next.js (App Router) + TypeScript + Prisma. Validação de entrada em
TypeScript puro (sem biblioteca de esquemas), em funções de `lib/validacao/`.

## Escopo
- Resolva só a issue indicada. Não altere código fora do escopo dela.
- Não altere `AGENTS.md`, `REVIEW.md`, `CLAUDE.md` nem nada em `.github/`.

## Testes
- Escreva os testes a partir dos critérios de aceitação da issue.
- O nome de cada teste começa com o número do critério: "[C3] ...".
- Não altere testes existentes para fazê-los passar. Se achar que um
  teste está errado, explique na descrição do PR.
- Não use `.skip`, `.only` nem `test.todo` em código para merge.
- Para casos de entrada inválida, verifique a resposta de erro e
  que nada foi gravado no banco.

## Dados e segredos
- Nunca use dados pessoais reais em código, testes, seeds ou exemplos.
- Nunca coloque segredos no código nem em variáveis `NEXT_PUBLIC_*`.
- Logs não registram dados pessoais (registre IDs, não conteúdo).

## Segurança
- Toda Server Action e todo route handler verificam autenticação e
  autorização dentro de si mesmos (helper `obterSessao`).
- Consultas a dados de usuário filtram pelo dono do registro.
- Saída de modelo de IA é validada e exibida como texto.
- Liste na descrição do PR toda dependência nova e o motivo.
